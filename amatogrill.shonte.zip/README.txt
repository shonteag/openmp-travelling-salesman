FILE INPUT:

Number of Cities
Matrix

Example:

3
0 2 2
2 0 3
2 3 0